<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/google/get_account.php';
require_once __DIR__ . '/includes/google/get_bigcommerce_site.php';
session_start();
$instanceId = $_SESSION['instance_id']
    ?? $_SESSION['instanceid']
    ?? null;
if (!$instanceId) {
    header("Location: sign-in.php");
    exit;
}
$title = "Sitemap Management";
$subTitle = "SEO Tools";

/* -------------------------
   TIMEZONE
------------------------- */
$countryCode = $_SESSION['country_code'] ?? 'US';
$countryToTimezone = [
    'US' => 'America/New_York',
    'IN' => 'Asia/Kolkata',
    'GB' => 'Europe/London',
    'AU' => 'Australia/Sydney',
    'CA' => 'America/Toronto',
    'DE' => 'Europe/Berlin',
    'FR' => 'Europe/Paris',
    'AE' => 'Asia/Dubai',
];

$userTimezone = $countryToTimezone[$countryCode] ?? 'UTC';
function formatUserTime(string $datetime, string $timezone): string
{
    if (!$datetime) return '';
    $dt = new DateTime($datetime, new DateTimeZone('UTC'));
    $dt->setTimezone(new DateTimeZone($timezone));
    return $dt->format('M j, Y H:i');
}

/* -------------------------
   GOOGLE ACCOUNT
------------------------- */
$google = getGoogleAccountByShop($instanceId);
$isConnected = (
    $google &&
    (
        !empty($google['access_token']) ||
        !empty($google['refresh_token'])
    )
);

/* -------------------------
   Bigcommerce SITE
------------------------- */
$site = getEcwidSiteByInstance($instanceId);
$siteUrl = null;
$siteDomainDisplay = null;
$siteUrl = null;
$siteDomainDisplay = null;
if (!empty($site['site_url'])) {
    $siteUrl = rtrim($site['site_url'], '/');
    $siteDomainDisplay = preg_replace('#^https?://#', '', $siteUrl);
}

$sitemapUrl = $siteUrl
    ? $siteUrl . '/sitemap.xml'
    : null;
/* -------------------------
   SITEMAP DATA
------------------------- */
$stmt = $pdo->prepare("
    SELECT s.*,
           (
             SELECT COUNT(*)
             FROM sitemap_submission_logs l
             WHERE l.instance_id = s.instance_id
           ) AS submission_count
    FROM sitemaps s
    WHERE s.instance_id = ?
    ORDER BY s.id DESC
    LIMIT 1
");
$stmt->execute([$instanceId]);
$latest = $stmt->fetch(PDO::FETCH_ASSOC);
$stmt = $pdo->prepare("
    SELECT *
    FROM sitemap_submission_logs
    WHERE instance_id = ?
    ORDER BY id DESC
");
$stmt->execute([$instanceId]);
$historyRaw = $stmt->fetchAll(PDO::FETCH_ASSOC);
$history = array_map(fn($log) => [
    'status' => $log['status'],
    'http_code' => $log['http_code'],
    'submitted_at' => $log['submitted_at'],
    'google_response' => $log['google_response'],
], $historyRaw);
include './partials/layouts/layoutTop.php';
?>

<script>
  // Ensure APP_BASE is always a string and has no trailing slash
  window.APP_BASE = '<?= rtrim(APP_BASE, "/") ?>';
  console.log("APP_BASE set to:", window.APP_BASE);
</script>
<div class="page-wrapper">
    <?php if ($isConnected): ?>
        <div class="card h-full rounded-lg border-0 mb-8">
            <div class="card-body p-6">
                <div class="flex justify-between items-start">
                    <h3 class="text-xl font-semibold mb-6 flex items-center gap-2">
                        <i class="fa-solid fa-sitemap text-cstm-primary"></i>
                        Submit Sitemap to Google
                    </h3>
                    <?php if ($latest && $latest['status'] === 'Success'): ?>
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-success-100 text-success-600 dark:bg-success-600/25 dark:text-success-400 border border-success-400 dark:border-success-600">
                            <span class="w-2 h-2 rounded-full bg-success-600 mr-2"></span>
                            Healthy
                        </span>
                    <?php else: ?>
                        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-warning-100 text-warning-600 dark:bg-warning-600/25 dark:text-warning-400 border border-warning-400 dark:border-warning-600">
                            <span class="w-2 h-2 rounded-full bg-warning-600 mr-2"></span>
                            Idle
                        </span>
                    <?php endif; ?>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="text-sm font-medium text-neutral-600 dark:text-neutral-200">Connected Domain</label>
                        <input type="text"
                            class="input w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-200 border border-neutral-300 dark:border-neutral-600 mt-2"
                            readonly
                            value="<?= htmlspecialchars($siteDomainDisplay) ?>">
                    </div>
                    <div>
                        <label class="text-sm font-medium text-neutral-600 dark:text-neutral-200">Sitemap URL</label>
                        <input type="text"
                            id="sitemapUrl"
                            class="input w-full px-4 py-3 rounded-xl bg-neutral-100 dark:bg-neutral-800 dark:text-neutral-200 border border-neutral-300 dark:border-neutral-600 mt-2"
                            value="<?= htmlspecialchars($sitemapUrl) ?>">
                    </div>
                </div>

                <button id="submitSitemapBtn"
                    type="button"
                    data-instance="<?= $instanceId ?>"
                    class="btn btn-cstm-primary mt-6 flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                    Sync Sitemap Now
                </button>
            </div>
        </div>

        <?php if ($latest): ?>
            <div class="card h-full rounded-lg border-0 mb-8">
                <div class="card-body">
                    <h3 class="text-lg font-semibold mb-4">Latest Execution</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="p-4 bg-neutral-50 dark:bg-neutral-700 rounded-lg border border-neutral-200 dark:border-neutral-600">
                            <div class="text-sm text-neutral-500 dark:text-gray-200">Status</div>
                            <div class="text-lg font-bold <?= $latest['status'] === 'Success' ? 'text-success-600' : 'text-danger-600' ?>">
                                <?= htmlspecialchars($latest['status']) ?>
                            </div>
                        </div>
                        <div class="p-4 bg-neutral-50 dark:bg-neutral-700 rounded-lg border border-neutral-200 dark:border-neutral-600">
                            <div class="text-sm text-neutral-500 dark:text-gray-200">Attempts</div>
                            <div class="text-lg font-bold text-neutral-800 dark:text-neutral-200">
                                <?= (int)($latest['submission_count'] ?? 0) ?>
                            </div>
                        </div>
                        <div class="p-4 bg-neutral-50 dark:bg-neutral-700 rounded-lg border border-neutral-200 dark:border-neutral-600">
                            <div class="text-sm text-neutral-500 dark:text-gray-200">Last Submitted</div>
                            <div class="text-lg font-bold text-neutral-800 dark:text-neutral-200">
                               <?= !empty($latest['last_submitted_at'])
    ? htmlspecialchars(formatUserTime($latest['last_submitted_at'], $userTimezone))
    : 'N/A'
?>
                            </div>
                        </div>
                    </div>
                    <?php if (!empty($latest['last_status_message'])): ?>
                        <div class="mt-6">
                            <label class="text-sm text-neutral-500">Google Response</label>
                            <pre class="p-4 bg-neutral-900 text-white rounded-lg overflow-x-auto text-xs font-mono mt-2"><?= htmlspecialchars($latest['last_status_message']) ?></pre>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

<div class="card h-full rounded-lg border-0 mb-8">
    <div class="card-body">
        <h3 class="text-lg font-semibold mb-4">Submission History</h3>

        <div class="cstm-scroll-sm overflow-x-auto">
            <table class="table bordered-table sm-table mb-0 table-fixed w-full text-sm">
                <thead>
                    <tr>
                        <th class="w-1/2 text-left">Sitemap URL</th>
                        <th class="w-1/4 text-center">Status</th>
                        <th class="w-1/4 text-left">Date</th>
                    </tr>
                </thead>
                <tbody id="submission-history-tbody">
                    <?php if (empty($history)): ?>
                        <tr>
                            <td colspan="3" class="text-center py-10 text-neutral-500">
                                No sitemap submissions yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div id="submission-history-pagination"
             class="card-footer bg-transparent border-t border-gray-200 dark:border-neutral-600 p-3 flex justify-end items-center gap-2"
             style="display: none;">
        </div>

    </div>
</div>

    <?php else: ?>

        <div class="h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-800 rounded-xl shadow-sm border border-neutral-200 dark:border-neutral-600 p-12 text-center min-h-[400px]">
            <div class="w-20 h-20 bg-neutral-100 dark:bg-neutral-700/50 rounded-full flex items-center justify-center mb-6">
                <iconify-icon icon="solar:lock-keyhole-bold-duotone" class="text-4xl text-neutral-400 dark:text-neutral-500"></iconify-icon>
            </div>
            <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-2">Sitemap Tools Locked</h3>
            <p class="text-gray-500 dark:text-gray-400 max-w-md mx-auto mb-8">
                To submit sitemaps and view submission history, you must first connect your Google Account.
            </p>
            <a href="setup-wizard.php?step=1" class="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-lg transition-colors">
                Connect Google Account
            </a>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {

    /* ==========================================
       SITEMAP SUBMISSION (CLEAN FINAL VERSION)
    ========================================== */

    const btn = document.getElementById("submitSitemapBtn");
    if (btn) {

        btn.addEventListener("click", async () => {

            const original = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<span class="loader mr-2"></span> Submitting...`;

            try {
                const res = await fetch(window.APP_BASE + "/api/google/submit_sitemap.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        instanceId: btn.dataset.instance, // match domain page pattern
                        sitemap_url: document.getElementById("sitemapUrl").value.trim()
                    })
                });

                const json = await res.json();

                if (!res.ok || !json.success) {
                    throw new Error(json.error || json.message || "Submission failed");
                }

                btn.innerHTML = "✔ Submitted!";
                setTimeout(() => location.reload(), 1000);

            } catch (err) {
                alert("Error: " + err.message);
                btn.disabled = false;
                btn.innerHTML = original;
            }
        });
    }


    /* ==========================================
       PAGINATION (UNCHANGED LOGIC, CLEANED)
    ========================================== */

    const allHistoryData = <?= json_encode($history) ?>;
    const sitemapUrlDisplay = "<?= htmlspecialchars($sitemapUrl ?? 'NA') ?>";
    const userTimezone = "<?= $userTimezone ?>";

    const historyTbody = document.getElementById("submission-history-tbody");
    const paginationContainer = document.getElementById("submission-history-pagination");

    if (!historyTbody || !paginationContainer) return;

    const ITEMS_PER_PAGE = 10;
    let currentPage = 1;

    function formatDate(datetime) {
        if (!datetime) return "";
        const utcDate = new Date(datetime + " UTC");
        return utcDate.toLocaleString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            hour12: false,
            timeZone: userTimezone
        });
    }

    function escapeHtml(text) {
        const div = document.createElement("div");
        div.textContent = text;
        return div.innerHTML;
    }

    function renderHistoryPage(page) {

        historyTbody.innerHTML = "";

        if (!allHistoryData.length) {
            historyTbody.innerHTML =
                '<tr><td colspan="5" class="text-center py-10 text-neutral-500">No sitemap submissions yet.</td></tr>';
            paginationContainer.style.display = "none";
            return;
        }

        const totalPages = Math.ceil(allHistoryData.length / ITEMS_PER_PAGE);
        currentPage = Math.max(1, Math.min(page, totalPages));

        const start = (currentPage - 1) * ITEMS_PER_PAGE;
        const items = allHistoryData.slice(start, start + ITEMS_PER_PAGE);

        items.forEach(log => {

            const statusBadge = log.status === "Success"
                ? '<span class="badge text-xs bg-success-100 dark:bg-success-600/25 text-success-600 dark:text-success-400 rounded-full px-2 py-1 font-semibold">Success</span>'
                : '<span class="badge text-xs bg-danger-100 dark:bg-danger-600/25 text-danger-600 dark:text-danger-400 rounded-full px-2 py-1 font-semibold">Failed</span>';

            const responsePreview = log.google_response
                ? escapeHtml(log.google_response.substring(0, 60)) + "..."
                : "N/A";

        historyTbody.innerHTML += `
    <tr>
        <td class="w-1/2">${escapeHtml(sitemapUrlDisplay)}</td>
        <td class="w-1/4 text-center">${statusBadge}</td>
        <td class="w-1/4">${escapeHtml(formatDate(log.submitted_at))}</td>
    </tr>
`;
        });

        renderPagination(totalPages);
    }

    function renderPagination(totalPages) {

        paginationContainer.innerHTML = "";

        if (totalPages <= 1) {
            paginationContainer.style.display = "none";
            return;
        }

        paginationContainer.style.display = "flex";

        function createBtn(label, page, disabled, active) {
            const el = document.createElement("button");
            el.textContent = label;
            el.className =
                "px-3 py-1 rounded-md text-sm font-medium " +
                (active
                    ? "bg-cstm-primary text-white"
                    : "bg-gray-100 dark:bg-neutral-700 hover:bg-gray-200 dark:hover:bg-neutral-600");

            if (disabled) {
                el.disabled = true;
                el.classList.add("opacity-50", "cursor-not-allowed");
            }

            el.addEventListener("click", () => renderHistoryPage(page));
            return el;
        }

        paginationContainer.appendChild(
            createBtn("Prev", currentPage - 1, currentPage === 1, false)
        );

        for (let i = 1; i <= totalPages; i++) {
            paginationContainer.appendChild(
                createBtn(i, i, false, i === currentPage)
            );
        }

        paginationContainer.appendChild(
            createBtn("Next", currentPage + 1, currentPage === totalPages, false)
        );
    }

    renderHistoryPage(1);
});
</script>
<?php include './partials/layouts/layoutBottom.php'; ?>
