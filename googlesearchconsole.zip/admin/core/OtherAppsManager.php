<?php
declare(strict_types=1);

class OtherAppsManager
{
    private static ?PDO $pdo = null;

    public static function initialize(PDO $pdo): void
    {
        self::$pdo = $pdo;
    }

    /* =====================================================
       GET FILTERED APPS
    ===================================================== */
    public static function getFilteredApps(string $search = '', int $perPage = 10, int $page = 1): array
    {
        if (!self::$pdo) {
            throw new RuntimeException("OtherAppsManager not initialized with PDO");
        }

        $offset = ($page - 1) * $perPage;

        $sql = "SELECT * FROM other_apps WHERE 1";
        $params = [];

        if (!empty($search)) {
            $sql .= " AND (title LIKE :search OR subtitle LIKE :search OR description LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }

        $sql .= " ORDER BY sort_order ASC, created_at DESC LIMIT :offset, :limit";

        $stmt = self::$pdo->prepare($sql);

        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val, PDO::PARAM_STR);
        }

        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int)$perPage, PDO::PARAM_INT);

        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /* =====================================================
       TOTAL APPS COUNT
    ===================================================== */
    public static function getTotalApps(string $search = ''): int
    {
        if (!self::$pdo) {
            throw new RuntimeException("OtherAppsManager not initialized with PDO");
        }

        $sql = "SELECT COUNT(*) FROM other_apps WHERE 1";
        $params = [];

        if (!empty($search)) {
            $sql .= " AND (title LIKE :search OR subtitle LIKE :search OR description LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }

        $stmt = self::$pdo->prepare($sql);
        $stmt->execute($params);

        return (int)$stmt->fetchColumn();
    }

    /* =====================================================
       GET SINGLE APP
    ===================================================== */
    public static function getAppById(int $id): ?array
    {
        if (!self::$pdo) {
            throw new RuntimeException("OtherAppsManager not initialized with PDO");
        }

        $stmt = self::$pdo->prepare("SELECT * FROM other_apps WHERE id = :id LIMIT 1");
        $stmt->execute([':id' => $id]);

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /* =====================================================
       CREATE APP
    ===================================================== */
    public static function createApp(array $data): bool
    {
        if (!self::$pdo) {
            throw new RuntimeException("OtherAppsManager not initialized with PDO");
        }

        $sql = "INSERT INTO other_apps (
                    title,
                    subtitle,
                    description,
                    image_url,
                    button_text,
                    app_price,
                    app_name,
                    integration_id,
                    -- version_id,
                    status,
                    sort_order,
                    is_index
                ) VALUES (
                    :title,
                    :subtitle,
                    :description,
                    :image_url,
                    :button_text,
                    :app_price,
                    :app_name,
                    :integration_id,
                    -- :version_id,
                    :status,
                    :sort_order,
                    :is_index
                )";

        $stmt = self::$pdo->prepare($sql);

        return $stmt->execute([
            ':title'          => $data['title'] ?? '',
            ':subtitle'       => $data['subtitle'] ?? '',
            ':description'    => $data['description'] ?? '',
            ':image_url'      => $data['image_url'] ?? null,
            ':button_text'    => $data['button_text'] ?? 'Install Now',
            ':app_price'      => $data['app_price'] ?? '0',
            ':app_name'       => $data['app_name'] ?? '',
            ':integration_id' => $data['integration_id'] ?? '',
            // ':version_id'     => $data['version_id'] ?? '',
            ':status'         => $data['status'] ?? 'active',
            ':sort_order'     => (int)($data['sort_order'] ?? 0),
            ':is_index'       => $data['is_index'] ?? 'disable',
        ]);
    }

    /* =====================================================
       UPDATE APP
    ===================================================== */
    public static function updateApp(int $id, array $data): bool
    {
        if (!self::$pdo) {
            throw new RuntimeException("OtherAppsManager not initialized with PDO");
        }

        $sql = "UPDATE other_apps SET
                    title = :title,
                    subtitle = :subtitle,
                    description = :description,
                    image_url = :image_url,
                    button_text = :button_text,
                    app_price = :app_price,
                    app_name = :app_name,
                    integration_id = :integration_id,
                    -- version_id = :version_id,
                    status = :status,
                    sort_order = :sort_order,
                    is_index = :is_index,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :id";

        $stmt = self::$pdo->prepare($sql);

        return $stmt->execute([
            ':title'          => $data['title'] ?? '',
            ':subtitle'       => $data['subtitle'] ?? '',
            ':description'    => $data['description'] ?? '',
            ':image_url'      => $data['image_url'] ?? null,
            ':button_text'    => $data['button_text'] ?? 'Install Now',
            ':app_price'      => $data['app_price'] ?? '0',
            ':app_name'       => $data['app_name'] ?? '',
            ':integration_id' => $data['integration_id'] ?? '',
            // ':version_id'     => $data['version_id'] ?? '',
            ':status'         => $data['status'] ?? 'active',
            ':sort_order'     => (int)($data['sort_order'] ?? 0),
            ':is_index'       => $data['is_index'] ?? 'disable',
            ':id'             => $id,
        ]);
    }

    /* =====================================================
       DELETE APP
    ===================================================== */
    public static function deleteApp(int $id): bool
    {
        if (!self::$pdo) {
            throw new RuntimeException("OtherAppsManager not initialized with PDO");
        }

        $stmt = self::$pdo->prepare("DELETE FROM other_apps WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    /* =====================================================
       BUILD GOHIGHLEVEL MARKETPLACE URL
    ===================================================== */
public static function buildMarketplaceUrl(?string $integrationId): ?string
{
    if (empty($integrationId)) {
        return null;
    }

    return 'https://marketplace.gohighlevel.com/integration/'
        . urlencode($integrationId)
        . '/versions/'
        . urlencode($integrationId);
}
}