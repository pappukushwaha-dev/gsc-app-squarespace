<?php
$title = 'Add App';
$subTitle = 'Add a new app to Our Other Apps';

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/core/SessionManager.php';
require_once __DIR__ . '/core/AuthController.php';
require_once __DIR__ . '/core/OtherAppsManager.php';

SessionManager::startDatabaseSession();

if (!AuthController::isAuthenticated()) {
    header('Location: ' . APP_BASE . '/admin/sign-in.php');
    exit;
}

OtherAppsManager::initialize($pdo);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $data = [
        'title'          => trim($_POST['title'] ?? ''),
        'subtitle'       => trim($_POST['subtitle'] ?? ''),
        'description'    => trim($_POST['description'] ?? ''),
        'image_url'      => trim($_POST['image_url'] ?? ''),
        'button_text'    => trim($_POST['button_text'] ?? 'Install Now'),
        'app_price'      => trim($_POST['app_price'] ?? '0'),
        'app_name'       => trim($_POST['app_name'] ?? ''),
        'integration_id' => trim($_POST['integration_id'] ?? ''),
        // 'version_id'     => trim($_POST['version_id'] ?? ''),
        'status'         => $_POST['status'] ?? 'active',
        'sort_order'     => (int)($_POST['sort_order'] ?? 0),
        'is_index'       => $_POST['is_index'] ?? 'disable',
    ];

    if ($data['title'] === '') $errors[] = 'Title is required.';
    if ($data['app_name'] === '') $errors[] = 'App ID is required.';
    if ($data['integration_id'] === '') $errors[] = 'Integration ID is required.';
    // if ($data['version_id'] === '') $errors[] = 'Version ID is required.';

    if (empty($errors)) {
        if (OtherAppsManager::createApp($data)) {
            header("Location: our-apps.php?msg=added");
            exit;
        } else {
            $errors[] = 'Failed to add app.';
        }
    }
}

include './partials/layouts/layoutTop.php';
?>

<div class="card rounded-xl border-0 overflow-hidden">
    <div class="card-header border-b bg-white py-4 px-6">
        <h6 class="text-lg font-semibold">Add New App</h6>
    </div>

    <div class="card-body p-6">

        <?php if (!empty($errors)): ?>
            <div class="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
                <?php foreach ($errors as $err): ?>
                    <p><?php echo htmlspecialchars($err); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                <div>
                    <label class="block mb-2 text-sm font-medium">Title *</label>
                    <input type="text" name="title" class="form-control rounded-lg" required>
                </div>

                <div>
                    <label class="block mb-2 text-sm font-medium">Subtitle</label>
                    <input type="text" name="subtitle" class="form-control rounded-lg">
                </div>

                <div class="md:col-span-2">
                    <label class="block mb-2 text-sm font-medium">Description</label>
                    <textarea name="description" rows="5" class="form-control rounded-lg"></textarea>
                </div>

                <div>
                    <label class="block mb-2 text-sm font-medium">Image URL</label>
                    <input type="text" name="image_url" class="form-control rounded-lg">
                </div>

                <div>
                    <label class="block mb-2 text-sm font-medium">App ID *</label>
                    <input type="text" name="app_name" class="form-control rounded-lg" required>
                </div>

                <div>
                    <label class="block mb-2 text-sm font-medium">Integration ID *</label>
                    <input type="text" name="integration_id" class="form-control rounded-lg" required>
                </div>

                <!-- <div>
                    <label class="block mb-2 text-sm font-medium">Version ID *</label>
                    <input type="text" name="version_id" class="form-control rounded-lg" required>
                </div> -->

                <div>
                    <label class="block mb-2 text-sm font-medium">Button Text</label>
                    <input type="text" name="button_text" class="form-control rounded-lg" value="Install Now">
                </div>

                <div>
                    <label class="block mb-2 text-sm font-medium">App Price</label>
                    <input type="text" name="app_price" class="form-control rounded-lg" value="0">
                </div>

                <div>
                    <label class="block mb-2 text-sm font-medium">Status</label>
                    <select name="status" class="form-select rounded-lg">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>

                <div>
                    <label class="block mb-2 text-sm font-medium">Sort Order</label>
                    <input type="number" name="sort_order" class="form-control rounded-lg" value="0">
                </div>

                <!-- Toggle -->
                <div>
                    <label class="block mb-2 text-sm font-medium">App on Dashboard</label>

                    <div class="flex items-center gap-4">
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox"
                                   name="is_index"
                                   value="enable"
                                   class="sr-only peer"
                                   id="isIndexToggle">

                            <div id="indexToggleBg"
                                 class="w-11 h-6 bg-danger-500 rounded-full transition-colors duration-300
                                        peer-checked:after:translate-x-full
                                        after:content-['']
                                        after:absolute after:top-[2px] after:left-[2px]
                                        after:bg-white after:border after:rounded-full
                                        after:h-5 after:w-5 after:transition-all">
                            </div>
                        </label>

                        <span id="indexLabel"
                              class="text-sm font-medium text-red-500">
                            Disabled
                        </span>
                    </div>
                </div>

            </div>

            <div class="mt-6 flex gap-6">
                <button type="submit" class="btn btn-cstm-primary">Add App</button>
                <a href="our-apps.php" class="btn bg-neutral-300">Cancel</a>
            </div>

        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const toggle = document.getElementById('isIndexToggle');
    const label = document.getElementById('indexLabel');
    const bg = document.getElementById('indexToggleBg');

    function syncToggle() {
        if (toggle.checked) {

            label.textContent = 'Enabled';
            label.classList.remove('text-red-500');
            label.classList.add('text-green-500');

            bg.classList.remove('bg-danger-500');
            bg.classList.add('bg-success-500');

        } else {

            label.textContent = 'Disabled';
            label.classList.remove('text-green-500');
            label.classList.add('text-red-500');

            bg.classList.remove('bg-success-500');
            bg.classList.add('bg-danger-500');
        }
    }

    toggle.addEventListener('change', syncToggle);
    syncToggle();
});
</script>

<?php include './partials/layouts/layoutBottom.php'; ?>