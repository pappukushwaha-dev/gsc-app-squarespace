document.addEventListener("DOMContentLoaded", () => {

    const formContainer      = document.getElementById("sitemap-submission-form");
    const successSection     = document.getElementById("sitemap-success-section");
    const btn                = document.getElementById("submitSitemapBtn");
    const box                = document.getElementById("sitemapStatusBox");
    const historyBox         = document.getElementById("sitemapHistory");
    const confettiContainer  = document.getElementById("confetti-container");
    const reviewModelOpen    = document.getElementById("reviewModal");

    // Reconnect elements
    const reconnectWrapper    = document.getElementById("reconnectGoogleWrapper");
    const reconnectBtn        = document.getElementById("reconnectGoogleBtn");
    const reconnectModal      = document.getElementById("reconnect-modal");
    const reconnectOverlay    = document.getElementById("reconnect-modal-overlay");
    const cancelReconnectBtn  = document.getElementById("cancelReconnect");
    const confirmReconnectBtn = document.getElementById("confirmReconnect");

    if (!btn) return;

    /* ==========================================================
       STATUS BOX
    ========================================================== */
    function setStatus({ type = "info", text = "", loading = false }) {
        if (!box) return;

        box.classList.remove(
            "hidden",
            "border-success-200", "bg-success-100", "text-success-600",
            "border-danger-200", "bg-danger-100", "text-danger-600",
            "border-neutral-200", "bg-neutral-50", "text-neutral-700"
        );

        box.classList.add("rounded-xl", "p-4", "border");

        if (type === "success") {
            box.classList.add("border-success-200", "bg-success-100", "text-success-600");
        } else if (type === "error") {
            box.classList.add("border-danger-200", "bg-danger-100", "text-danger-600");
        } else {
            box.classList.add("border-neutral-200", "bg-neutral-50", "text-neutral-700");
        }

        box.innerHTML = loading
            ? `<span class="loader inline-block mr-2"></span> ${text}`
            : text;
    }

    /* ==========================================================
       SAFE POST JSON
    ========================================================== */
    async function postJson(url, data) {
        const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "same-origin",
            body: JSON.stringify(data)
        });

        let text = "";
        try { text = await res.text(); } catch {}

        let json;
        try {
            json = JSON.parse(text);
        } catch {
            return { success: false, error: "invalid_json", raw: text, http: res.status };
        }

        json.fetch_http = res.status;
        return json;
    }

    /* ==========================================================
       LOAD SITEMAP HISTORY
    ========================================================== */
    async function loadHistory() {
        if (!historyBox) return;

        historyBox.textContent = "Loading...";

        const instanceId = btn.dataset.instance;
        if (!instanceId) {
            historyBox.textContent = "Missing instance ID.";
            return;
        }

        try {
            const res = await fetch(
                `${window.APP_BASE}/api/google/fetch_sitemaps.php?instanceId=${encodeURIComponent(instanceId)}`,
                { credentials: "same-origin" }
            );

            const text = await res.text();
            const json = JSON.parse(text);

            if (!json.success || !Array.isArray(json.logs) || json.logs.length === 0) {
                historyBox.textContent = "No submissions yet.";
                return;
            }

            let html = `<ul class="space-y-3">`;

            json.logs.forEach(log => {
                const status = (log.status || '').toUpperCase();
                const statusColor =
                    status === 'SUCCESS' ? 'text-green-600' :
                    status === 'FAILED'  ? 'text-red-600' :
                    'text-neutral-600';

                const statusIcon =
                    status === 'SUCCESS' ? '✅' :
                    status === 'FAILED'  ? '❌' : 'ℹ️';

                html += `
                    <li class="border p-3 rounded-xl bg-neutral-50 dark:bg-neutral-700/40">
                        <div class="font-semibold break-all">${log.sitemap_url || ''}</div>
                        <div class="${statusColor}">Status: ${statusIcon} ${status}</div>
                        <div>HTTP: ${log.http_code ?? ''}</div>
                        <div class="text-xs">At: ${log.submitted_at ?? ''}</div>
                    </li>
                `;
            });

            html += `</ul>`;
            historyBox.innerHTML = html;

        } catch (e) {
            historyBox.textContent = "Error loading history.";
        }
    }

    /* ==========================================================
       SUCCESS UI
    ========================================================== */
    function showSuccessUI() {
        if (formContainer) formContainer.classList.add('hidden');

        if (successSection) {
            successSection.classList.remove('hidden');
            setTimeout(() => successSection.classList.add("show"), 50);
        }

        if (reviewModelOpen) {
            setTimeout(() => reviewModelOpen.classList.remove("hidden"), 3000);
        }

        if (confettiContainer) {
            confettiContainer.innerHTML = '';
            for (let i = 0; i < 25; i++) {
                const conf = document.createElement("div");
                conf.className = "confetti";
                conf.style.left = `${Math.random() * 100}%`;
                conf.style.background = ["#22c55e", "#16a34a", "#86efac", "#15803d"][Math.floor(Math.random() * 4)];
                conf.style.animationDelay = `${Math.random() * 2}s`;
                confettiContainer.appendChild(conf);
            }
        }
    }

    /* ==========================================================
       RECONNECT MODAL
    ========================================================== */
    function openReconnectModal() {
        if (!reconnectModal || !reconnectOverlay) return;
        reconnectModal.classList.remove("hidden");
        reconnectOverlay.classList.remove("hidden");

        requestAnimationFrame(() => {
            reconnectModal.classList.remove("opacity-0", "scale-95");
            reconnectOverlay.classList.remove("opacity-0");
        });
    }

    function closeReconnectModal() {
        if (!reconnectModal || !reconnectOverlay) return;
        reconnectModal.classList.add("opacity-0", "scale-95");
        reconnectOverlay.classList.add("opacity-0");

        setTimeout(() => {
            reconnectModal.classList.add("hidden");
            reconnectOverlay.classList.add("hidden");
        }, 200);
    }

    reconnectBtn?.addEventListener("click", e => {
        e.preventDefault();
        // If reconnect wrapper is already visible (not hidden), redirect directly
        if (reconnectWrapper && !reconnectWrapper.classList.contains("hidden")) {
            window.location.href = `${window.APP_BASE || '/hl/google_search_console'}/setup-wizard.php?step=1`;
        } else {
            openReconnectModal();
        }
    });

    cancelReconnectBtn?.addEventListener("click", e => {
        e.preventDefault();
        closeReconnectModal();
    });

    reconnectOverlay?.addEventListener("click", closeReconnectModal);

    confirmReconnectBtn?.addEventListener("click", e => {
        e.preventDefault();
        window.location.href = "/hl/google_search_console/setup-wizard.php?step=1";
    });

    /* ==========================================================
       INITIAL LOAD
    ========================================================== */
    loadHistory();

    /* ==========================================================
       SUBMIT SITEMAP (FINAL + FIXED)
    ========================================================== */
    btn.addEventListener("click", async () => {

        const instanceId = btn.dataset.instance;
        const sitemapInput = document.getElementById("sitemapInput");
        const sitemapUrl = sitemapInput ? sitemapInput.value.trim() : "";

        if (!instanceId) {
            setStatus({ type: "error", text: "Missing instance ID." });
            return;
        }

        if (!sitemapUrl) {
            setStatus({ type: "error", text: "Please enter a sitemap URL." });
            return;
        }

        btn.disabled = true;
        setStatus({ type: "info", text: "Submitting sitemap...", loading: true });

        const res = await postJson(
            `${window.APP_BASE}/api/google/submit_sitemap.php`,
            {
                instance_id: instanceId,
                sitemap_url: sitemapUrl
            }
        );

        console.log("submit_sitemap response:", res);

        if (!res.success) {
            let msg = "Submission failed.";

            if (res.error === 'account_needs_reconnect' || res.http === 401 || res.http === 403) {
                msg = "Your Google connection has expired or permissions were revoked. Please reconnect.";
                reconnectWrapper?.classList.remove("hidden");
            } else if (res.error) {
                msg = res.error;
            } else if (res.http && res.http >= 400) {
                msg = `Submission failed with HTTP ${res.http}. ${res.error || 'Please check your sitemap URL and try again.'}`;
            }

            console.error("Sitemap submission error:", res);
            setStatus({ type: "error", text: msg });
            btn.disabled = false;
            return;
        }

        setStatus({ type: "success", text: "Sitemap submitted successfully!" });
        loadHistory();

        fetch('/hl/google_search_console/api/update-step.php', {
            method: 'POST',
            credentials: 'same-origin',
            body: new URLSearchParams({ step: '3' })
        }).catch(() => {});

        setTimeout(showSuccessUI, 1500);
        btn.disabled = false;
    });

});
