# Google Search Console for Shopify

A Shopify app that integrates Google Search Console functionality, allowing merchants to manage sitemaps, verify domains, and view search analytics directly from their Shopify admin.

## Features

- ✅ **Google OAuth Integration** - Connect your Google account securely
- ✅ **Domain Verification** - Verify domain ownership in Google Search Console
- ✅ **Sitemap Submission** - Submit and manage sitemaps automatically
- ✅ **Search Analytics** - View clicks, impressions, CTR, and position data
- ✅ **Submission History** - Track all sitemap submissions with detailed logs
- ✅ **Automatic Token Refresh** - Handles Google OAuth token refresh automatically

## Installation

### 1. Database Setup

Import the provided SQL file to create all necessary tables:

```bash
mysql -u root -p shopify_googlesearchconsole < googlesearchconsole_shopify.sql
```

### 2. Environment Configuration

Create a `.env` file in the root directory:

```env
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=shopify_googlesearchconsole
DB_USER=root
DB_PASS=your_password

APP_ENV=production
APP_DEBUG=0
APP_TIMEZONE=UTC

ENCRYPTION_SECRET=your-32-character-secret-key-here!!
```

### 3. Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable **Google Search Console API** and **Site Verification API**
4. Create OAuth 2.0 credentials
5. Add authorized redirect URI: `https://yourdomain.com/shopify/googlesearchconsole/google_oauth_callback.php`
6. Insert credentials into `google_settings` table:

```sql
INSERT INTO google_settings (client_id, client_secret, redirect_uri) 
VALUES (
    'your-client-id.apps.googleusercontent.com',
    'encrypted-secret-here',  -- Use encrypt() function
    'https://yourdomain.com/shopify/googlesearchconsole/google_oauth_callback.php'
);
```

### 4. Shopify App Setup

1. Create a new app in [Shopify Partners](https://partners.shopify.com/)
2. Set App URL: `https://yourdomain.com/shopify/googlesearchconsole`
3. Set Allowed redirection URL(s): `https://yourdomain.com/shopify/googlesearchconsole/auth/callback.php`
4. Update `config.php` with your Shopify credentials:
   - `SHOPIFY_API_KEY`
   - `SHOPIFY_API_SECRET`
   - `SHOPIFY_SCOPES`
   - `APP_URL`

### 5. Composer Dependencies

Install PHP dependencies:

```bash
composer install
```

Required packages:
- `google/apiclient` - Google API client
- `vlucas/phpdotenv` - Environment variable management

## File Structure

```
googlesearchconsole_shopify/
├── api/
│   └── google/
│       ├── submit_sitemap.php      # Submit sitemap to Google
│       └── verify_domain.php       # Verify domain ownership
├── auth/
│   ├── install.php                 # Shopify OAuth install
│   └── callback.php                # Shopify OAuth callback
├── includes/
│   ├── config.php                  # App configuration
│   ├── db.php                      # Database connection
│   ├── credentials.php             # Encryption helpers
│   └── google/
│       ├── get_account.php         # Get Google account by shop
│       ├── save_token.php          # Save Google OAuth tokens
│       ├── token_manager.php       # Token refresh management
│       └── refresh_token.php       # Refresh Google tokens
├── webhook/
│   └── webhook_uninstall.php       # Handle app uninstall
├── dashboard.php                   # Main dashboard
├── setup-wizard.php                # Setup wizard
├── google_oauth_callback.php       # Google OAuth callback
├── index.php                       # App Bridge entry point
└── config.php                      # Main config file
```

## Usage

### For Merchants

1. **Install the App**: Install from Shopify App Store
2. **Connect Google**: Click "Connect Google Account" in setup wizard
3. **Verify Domain**: Enter your domain URL to verify ownership
4. **Submit Sitemap**: Submit your sitemap URL (usually `https://yourstore.com/sitemap.xml`)
5. **View Analytics**: Access dashboard to see search performance data

### For Developers

#### API Endpoints

**Submit Sitemap**
```php
POST /api/google/submit_sitemap.php
{
    "shop": "store.myshopify.com",
    "instance_id": "shp_...",
    "sitemapUrl": "https://store.com/sitemap.xml"
}
```

**Verify Domain**
```php
POST /api/google/verify_domain.php
{
    "shop": "store.myshopify.com",
    "instance_id": "shp_...",
    "domain": "https://store.com"
}
```

## Database Schema

Key tables:
- `ShopifySite` - Stores Shopify shop information
- `google_accounts` - Google OAuth tokens per shop
- `gsc_domain_verifications` - Domain verification status
- `sitemaps` - Sitemap submission records
- `sitemap_submission_logs` - Detailed submission history

## Security

- All client secrets are encrypted using AES-256-CBC
- HMAC verification for all Shopify webhooks
- OAuth state parameter validation
- SQL injection protection via prepared statements
- XSS protection via `htmlspecialchars()`

## Troubleshooting

### Google OAuth Issues

- Ensure redirect URI matches exactly in Google Console
- Check that OAuth consent screen is configured
- Verify API scopes are enabled

### Token Refresh Failures

- Check `google_settings` table has correct credentials
- Verify encryption key is correct
- Check error logs for detailed messages

### Database Connection

- Verify `.env` file exists and has correct credentials
- Check database user has proper permissions
- Ensure database exists and tables are created

## Support

For issues or questions, please contact support or check the documentation.

## License

Proprietary - All rights reserved

