<?php
// includes/config.php
declare(strict_types=1);

/* ==========================================================
   AUTOLOADER (.env)
========================================================== */
require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->safeLoad(); // no fatal error if .env missing


/* ==========================================================
   DATABASE CONNECTION (PDO)
========================================================== */
require_once __DIR__ . '/db.php'; // ensures $pdo is available


/* ==========================================================
   APPLICATION ENVIRONMENT
========================================================== */
$APP_ENV      = $_ENV['APP_ENV']      ?? 'production';
$APP_DEBUG    = ($_ENV['APP_DEBUG'] ?? '0') === '1';
$APP_TIMEZONE = $_ENV['APP_TIMEZONE'] ?? 'UTC';

date_default_timezone_set($APP_TIMEZONE);


/* ==========================================================
   APPLICATION CONSTANTS
========================================================== */

/*
 | IMPORTANT RULE:
 | - APP_BASE → NEVER end with slash
 | - APP_URL  → ALWAYS end with slash
 */

// Internal base path (used in routing)
define("APP_BASE", "/ecwid/googlesearchconsole");

// Public URL (used for redirects, OAuth callbacks, etc.)
define(
    "APP_URL",
    rtrim(
        $_ENV['APP_URL'] ?? "https://makkpressapps.com/ecwid/googlesearchconsole/",
        '/'
    ) . '/'
);

// 🔥 Proper HOST_URL for OAuth + redirects
// Always ends with slash
define("HOST_URL", APP_URL);


/* ==========================================================
   DEBUG MODE
========================================================== */

if ($APP_DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
}