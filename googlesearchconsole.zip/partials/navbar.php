<?php
require_once(__DIR__ . '/../includes/config.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| AUTHORITATIVE INSTANCE
|--------------------------------------------------------------------------
*/
$instanceId = $_SESSION['instance_id'] ?? $_GET['instance_id'] ?? null;

if (!$instanceId) {
    header('Location: sign-in.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| DEFAULTS
|--------------------------------------------------------------------------
*/
$userEmail       = 'N/A';
$shopDisplayName = 'Shop';
$initials        = 'SH';
$hasImage        = false;
$profileImageUrl = '';
$shopWebsiteUrl  = '';
$billingUrl      = 'pricing.php';

/*
|--------------------------------------------------------------------------
| LOAD STORE USING INSTANCE
|--------------------------------------------------------------------------
*/
try {
    $stmt = $pdo->prepare("
        SELECT 
            shop_name,
            email,
            domain,
            shop_domain
        FROM EcwidSite
        WHERE instance_id = ?
        LIMIT 1
    ");
    $stmt->execute([$instanceId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {

        // Email
        $userEmail = !empty($result['email'])
            ? htmlspecialchars($result['email'], ENT_QUOTES, 'UTF-8')
            : 'N/A';

        // Shop Name
        if (!empty($result['shop_name'])) {
            $shopDisplayName = htmlspecialchars($result['shop_name'], ENT_QUOTES, 'UTF-8');
        }

        // Generate initials
        $words = preg_split('/[\s@._-]+/', $shopDisplayName);
        $initials = '';
        foreach ($words as $word) {
            if ($word !== '') {
                $initials .= strtoupper($word[0]);
            }
        }
        $initials = substr($initials ?: 'SH', 0, 2);

        /*
        |--------------------------------------------------------------------------
        | Resolve Domain (domain → shop_domain)
        |--------------------------------------------------------------------------
        */
        $resolvedDomain = '';

        if (!empty($result['domain'])) {
            $resolvedDomain = trim($result['domain']);
        } elseif (!empty($result['shop_domain'])) {
            $resolvedDomain = trim($result['shop_domain']);
        }

        /*
        |--------------------------------------------------------------------------
        | Website URL
        |--------------------------------------------------------------------------
        */
        if ($resolvedDomain) {
            if (!preg_match('#^https?://#i', $resolvedDomain)) {
                $shopWebsiteUrl = 'https://' . htmlspecialchars($resolvedDomain, ENT_QUOTES, 'UTF-8');
            } else {
                $shopWebsiteUrl = htmlspecialchars($resolvedDomain, ENT_QUOTES, 'UTF-8');
            }
        }

    }

} catch (PDOException $e) {
    error_log('Header load error: ' . $e->getMessage());
}
?>

<!-- ========================================= -->
<!-- HEADER -->
<!-- ========================================= -->

<div class="navbar-header border-b border-neutral-200 dark:border-neutral-600">
    <div class="flex items-center justify-between">

        <!-- LEFT -->
        <div class="flex items-center gap-4">

            <button type="button" class="sidebar-toggle">
                <iconify-icon icon="heroicons:bars-3-solid" class="icon non-active"></iconify-icon>
                <iconify-icon icon="iconoir:arrow-right" class="icon active"></iconify-icon>
            </button>

            <!-- Upgrade (internal now, not Shopify billing) -->
            <a href="pricing.php">
                <button class="h-10 btn btn-cstm-primary flex items-center gap-2 px-3">
                    <iconify-icon icon="mdi:crown-outline" class="text-xl"></iconify-icon>
                    Upgrade
                </button>
            </a>

            <!-- WEBSITE BUTTON -->
            <?php if (!empty($shopWebsiteUrl)): ?>
                <a href="<?= $shopWebsiteUrl ?>"
                   target="_blank"
                   rel="noopener noreferrer"
                   class="group flex items-center gap-1 px-2 py-1.5 border dark:border-neutral-700 rounded-lg text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:border-cstm-primary hover:text-cstm-primary transition-all max-w-[280px] truncate mobile_d_none">
                    <iconify-icon icon="mdi:web" class="text-cstm-primary text-base"></iconify-icon>
                    <span><?= parse_url($shopWebsiteUrl, PHP_URL_HOST); ?></span>
                </a>
            <?php endif; ?>

        </div>

        <!-- RIGHT -->
        <div class="flex items-center gap-3 relative">

            <button id="open-header-ticket"
                    class="h-10 btn btn-cstm-primary flex items-center gap-2 px-3 mobile_d_none">
                <iconify-icon icon="mdi:headset" class="text-lg"></iconify-icon>
                Contact Support
            </button>

            <a href="instructions.php?instance_id=<?= urlencode($instanceId) ?>" class="mobile_d_none">
                <button class="h-10 btn btn-cstm-primary flex items-center gap-2 px-3">
                    <iconify-icon icon="mdi:file-document-outline" class="text-lg"></iconify-icon>
                    Installation Guide
                </button>
            </a>

            <!-- PROFILE -->
            <div class="relative">
                <button data-dropdown-toggle="dropdownProfile"
                        class="flex items-center justify-center rounded-full"
                        type="button">
                    <div class="w-10 h-10 rounded-full flex items-center justify-center bg-cstm-primary text-white font-bold text-lg">
                        <?= $initials ?>
                    </div>
                </button>

                <!-- DROPDOWN -->
                <div id="dropdownProfile"
                     class="hidden absolute right-0 top-12 bg-white dark:bg-neutral-800 rounded-lg shadow-lg border border-neutral-200 dark:border-neutral-600 p-3 min-w-max z-50">

                    <div class="py-3 px-4 rounded-lg bg-cstm-primary-10 drk-bg-cstm-primary-30 mb-4 flex justify-between gap-2">
                        <div>
                            <h6 class="text-lg font-semibold"><?= $userEmail ?></h6>
                            <span class="text-neutral-500"><?= $shopDisplayName ?></span>
                        </div>
                        <button type="button" id="dropdownCloseBtn">
                            <iconify-icon icon="radix-icons:cross-1" class="text-xl"></iconify-icon>
                        </button>
                    </div>

                    <ul class="space-y-1">
                        <li>
                            <a href="pricing.php"
                               class="block px-2 py-2 hover:bg-gray-100 dark:hover:bg-neutral-700 rounded">
                                Current Plan
                            </a>
                        </li>
                        <li>
                            <a href="settings.php?instance_id=<?= urlencode($instanceId) ?>"
                               class="block px-2 py-2 hover:bg-gray-100 dark:hover:bg-neutral-700 rounded">
                                Settings
                            </a>
                        </li>
                        <li>
                            <a href="logout.php"
                               class="block px-2 py-2 hover:bg-gray-100 dark:hover:bg-neutral-700 rounded text-danger-600">
                                Log Out
                            </a>
                        </li>
                    </ul>

                </div>
            </div>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    /*
    |--------------------------------------------------------------------------
    | Authoritative Data From PHP
    |--------------------------------------------------------------------------
    */
    const instanceId = <?= json_encode($instanceId ?? null, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
    const ownerEmail = <?= json_encode($userEmail ?? 'N/A', JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;

    /*
    |--------------------------------------------------------------------------
    | Ticket Popup Integration
    |--------------------------------------------------------------------------
    */
    if (window.TicketPopup) {

        if (typeof window.TicketPopup.setInstanceId === 'function') {
            window.TicketPopup.setInstanceId(instanceId);
        }

        if (typeof window.TicketPopup.setOwnerEmail === 'function') {
            window.TicketPopup.setOwnerEmail(ownerEmail);
        }

        // Open popup from header button
        const openBtn = document.getElementById('open-header-ticket');
        if (openBtn) {
            openBtn.addEventListener('click', function () {
                if (typeof window.TicketPopup.open === 'function') {
                    window.TicketPopup.open();
                }
            });
        }

        // Success callback
        window.TicketPopup.onSuccess = function () {

            // Refresh tickets list if available
            if (typeof fetchTickets === 'function') {
                try {
                    fetchTickets();
                } catch (err) {
                    console.warn('fetchTickets error:', err);
                }
            }

            // Show notification
            if (typeof showNotification === 'function') {
                showNotification('Ticket created successfully', 'success');
            } else {
                const toast = document.createElement('div');
                toast.textContent = 'Ticket created successfully';
                toast.style.cssText = `
                    position: fixed;
                    top: 12px;
                    right: 12px;
                    padding: 10px 14px;
                    background: #16a34a;
                    color: #fff;
                    border-radius: 8px;
                    z-index: 9999;
                `;
                document.body.appendChild(toast);
                setTimeout(() => toast.remove(), 3000);
            }
        };
    }

    /*
    |--------------------------------------------------------------------------
    | Profile Dropdown Toggle
    |--------------------------------------------------------------------------
    */
    const profileToggle = document.querySelector('[data-dropdown-toggle="dropdownProfile"]');
    const dropdown = document.getElementById('dropdownProfile');
    const closeBtn = document.getElementById('dropdownCloseBtn');

    if (profileToggle && dropdown) {
        profileToggle.addEventListener('click', function () {
            dropdown.classList.toggle('hidden');
        });
    }

    if (closeBtn && dropdown) {
        closeBtn.addEventListener('click', function () {
            dropdown.classList.add('hidden');
        });
    }

});
</script>