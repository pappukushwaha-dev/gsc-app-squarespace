<?php
$instanceId = $_SESSION['instance_id'] ?? null;


?>


<!-- Review Modal -->
<div id="reviewModal"
    class="fixed inset-0 flex bg-cstm-black-40 backdrop-blur-sm items-center justify-center z-99 shadow-lg hidden">

    <div class="bg-white dark:bg-neutral-800 rounded-xl shadow-2xl py-8 px-10 w-full max-w-2xl border-b-6 border-cstm-primary relative">

        <!-- Alert Message -->
        <div id="alertContainer" class="mb-4 transition-all duration-300"></div>

        <!-- Close Button -->
        <button id="closeReviewModal"
            class="absolute right-4 top-4 text-gray-500 hover:text-gray-700">
            ✕
        </button>
        <div id="ratingSection">

            <h2 class="text-xl font-bold text-center text-neutral-800 mb-4">
                Which of these best describes your experience with us?
            </h2>
            <!-- Ratings -->
            <div class="mb-2">
                <div id="ratingButtons" class="flex flex-wrap gap-3 justify-center"></div>
            </div>

            <!-- <p class="text-sm text-center text-neutral-400 mb-4 flex justify-between font-medium">
                <span>Not at all likely</span>
                <i class="fa-solid fa-arrow-right-long"></i>
                <span>Extremely likely</span>
            </p> -->
        </div>
        <!-- Comment box (only for <=7) -->
        <div id="commentBox" class="hidden mb-4">
            <label class="text-sm font-semibold text-neutral-700 dark:text-gray-400">
                Please share your comments:
            </label>

            <textarea id="reviewComment"
                class="w-full py-1 px-2 border border-gray-300 dark:border-neutral-600 rounded-lg transition duration-150 dark:bg-neutral-800"
                rows="3"
                placeholder="Tell us what we can improve..."></textarea>
        </div>
        <!-- Review Confirm Popup -->
        <div id="reviewConfirmPopup"
            class="hidden bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-xl p-6 shadow-sm">

            <!-- Icon (optional but recommended) -->
            <div class="flex items-center justify-center mb-4">
                <div class="w-12 h-12 rounded-full bg-primary-100 text-primary-600
                    flex items-center justify-center text-xl font-bold">
                    ★
                </div>
            </div>

            <!-- Title -->
            <h3 class="text-lg font-semibold text-center text-gray-900 dark:text-gray-100 mb-2">
                Thanks for the great feedback!
            </h3>

            <!-- Message -->
            <p id="reviewConfirmText"
                class="text-sm text-center text-gray-600 dark:text-gray-300 mb-6">
                Would you mind sharing this on our review page?
                It really helps other users discover us.
            </p>


            <!-- Actions -->
            <div class="flex justify-center gap-4">
                <button id="reviewNoBtn"
                    class="px-6 py-2 text-sm font-semibold text-white
                   bg-primary-600 hover:bg-primary-700
                   rounded-lg transition shadow">
                    No, thanks
                </button>

                <button id="reviewYesBtn"
                    class="px-6 py-2 text-sm font-semibold text-white
                   bg-primary-600 hover:bg-primary-700
                   rounded-lg transition shadow">
                    Yes, sure!
                </button>
            </div>
        </div>

        <div id="footerButtons"
            class="flex justify-center gap-4 pt-6 border-t border-gray-100 dark:border-neutral-600">
            <button id="alreadySubmittedBtn"
                class="btn btn-cstm-primary hidden">
                Already Submitted ?
            </button>

            <button id="reviewSubmit"
                class="btn btn-cstm-primary">
                Submit Feedback
            </button>



        </div>
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", () => {

        const modal = document.getElementById("reviewModal");
        const commentBox = document.getElementById("commentBox");
        const submitBtn = document.getElementById("reviewSubmit");
        const openBtn = document.getElementById("openReviewModal");
        const closeBtn = document.getElementById("closeReviewModal");
        const remindBtn = document.getElementById("reviewRemindLater");
        const alertContainer = document.getElementById("alertContainer");
        const alreadyBtn = document.getElementById("alreadySubmittedBtn");
        const confirmPopup = document.getElementById("reviewConfirmPopup");
        const confirmText = document.getElementById("reviewConfirmText");
        const yesBtn = document.getElementById("reviewYesBtn");
        const noBtn = document.getElementById("reviewNoBtn");
        let isCheckingReview = false;
        const experienceOptions = [
    { label: "Loved it", emoji: "😍", rating: 10 },
    { label: "Great so far", emoji: "🙂", rating: 9 },
    { label: "Good", emoji: "😐", rating: 7 },
    { label: "Needs improvement", emoji: "😕", rating: 5 }
];



        // const ratingMessages = {
        //     8: [
        //         "Amazing! Would you mind sharing this on our review page?",
        //         "Thanks for the feedback! Want to share this on our review page?"
        //     ],
        //     9: [
        //         "Amazing! Would you mind sharing this on our review page?",
        //         "Amazing! We'd really appreciate a review from you."

        //     ],
        //     10: [
        //         "Amazing! Would you mind sharing this on our review page?",
        //         "You made our day 🎉 Would you mind sharing this review publicly?"
        //     ]
        // };

        function getMessageByRating(rating) {
            if (rating >= 9) {
                return "Would you like to share your experience with others?";
            }
            return "";
        }


        let selectedRating = null;

        // ========= Highlight Saved Rating When Already Submitted =========
        function highlightSubmittedRating(rating) {
            document.querySelectorAll(".review-numbers").forEach(btn => {
                if (Number(btn.dataset.value) === Number(rating)) {
                    btn.classList.add("review-numbers-selected");
                } else {
                    btn.classList.remove("review-numbers-selected");
                }
            });
        }

        // ========= FUNCTION: Already Submitted UI =========
        function applyAlreadySubmittedState() {
            alertContainer.innerHTML = `
            <div class="bg-success-100 text-success-700 border-l-4 border-success-600 p-3 rounded-md text-sm font-medium mb-4">
                <i class="fa-solid fa-check-circle"></i> You already submitted your review.
            </div>
        `;

            // disable rating buttons
            document.querySelectorAll(".review-numbers").forEach(btn => {
                btn.disabled = true;
                btn.classList.add("opacity-40", "cursor-not-allowed");
            });

            // disable comment box
            document.getElementById("reviewComment").disabled = true;

            // disable submit button
            submitBtn.textContent = "Already Submitted";
            submitBtn.disabled = true;
            submitBtn.classList.add("opacity-50", "cursor-not-allowed");

            // 🔥 Hide Remind Me Later
            remindBtn?.classList.add("hidden");


            // 🔥 Show Close button
            closeBtn.classList.remove("hidden");
        }

        function reloadAfterDelay(ms = 2000) {
            setTimeout(() => {
                window.location.reload();
            }, ms);
        }

        // ========= COMMON SUBMIT FUNCTION (used by button + auto-submit) =========
        async function submitReview() {
            if (submitBtn.disabled) return;

            if (!selectedRating) {
                alertContainer.innerHTML = "";
                const warning = document.createElement("div");
                warning.className =
                    "bg-warning-100 text-warning-600 dark:bg-warning-600/20 border-l-4 border-warning-600 p-3 rounded-md text-sm font-medium mb-4 flex items-center gap-2";
                warning.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Please select a rating first.`;
                alertContainer.appendChild(warning);

                setTimeout(() => warning.remove(), 3000);
                return;
            }

            const comment = document.getElementById("reviewComment").value.trim();

            const response = await fetch("api/save-review.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    instance_id: "<?php echo $instanceId; ?>",
                    rating: selectedRating,
                    comment: comment
                })
            });

            const result = await response.json();
            if (result.success) {
                showAlert(result.message || "Review successfully submitted!", "success");

                if (selectedRating >= 8) {

                    // ❌ hide everything
                    document.getElementById("ratingSection").classList.add("hidden");
                    commentBox.classList.add("hidden");
                    document.getElementById("footerButtons").classList.add("hidden");

                    // ✅ SET DIFFERENT MESSAGE (OPTION 3)
                    confirmText.textContent = getMessageByRating(selectedRating);

                    // ✅ show ONLY confirm message
                    confirmPopup.classList.remove("hidden");

                    return; // keep modal open
                }

                modal.classList.add("hidden");
                redirectAfterReview();
            }


            // 1–7 → close modal
            modal.classList.add("hidden");
            redirectAfterReview();

        }
        yesBtn.addEventListener("click", () => {
            // TODO: replace with the real Ecwid App Market listing URL for this app
            window.open(
                `https://www.ecwid.com/apps`,
                "_blank"
            );
            modal.classList.add("hidden");
            // Don't redirect when closing - just hide the modal
        });

        noBtn.addEventListener("click", () => {
            confirmPopup.classList.add("hidden");
            modal.classList.add("hidden");
            // Don't redirect when closing - just hide the modal
        });

        // ========= Inject Rating Buttons =========
        const ratingContainer = document.getElementById("ratingButtons");

        // for (let i = 1; i <= 10; i++) {
        //     const btn = document.createElement("button");

        //     btn.textContent = i;
        //     btn.dataset.value = i;
        //     btn.className =
        //         `review-numbers w-10 h-10 flex items-center justify-center rounded-full text-white font-bold cursor-pointer transition bg-c${i}`;

        //     btn.addEventListener("click", () => {
        //         if (btn.disabled) return;

        //         selectedRating = i;

        //         [...ratingContainer.children].forEach(b =>
        //             b.classList.remove("review-numbers-selected")
        //         );

        //         btn.classList.add("review-numbers-selected");

        //         // Show comment box only for 1–7
        //         commentBox.classList.remove("hidden");


        //     });

        //     ratingContainer.appendChild(btn);
        // }
        experienceOptions.forEach(option => {
            const btn = document.createElement("button");

            btn.innerHTML = `
    <span class="text-lg">${option.emoji}</span>
    <span>${option.label}</span>
`;
            btn.dataset.value = option.rating;

btn.className = `
    flex items-center gap-2
     px-3 py-2 rounded-lg border
    font-semibold text-sm
    transition
    border-gray-300 dark:border-neutral-600
    hover:bg-primary-600 hover:text-white
`;

            btn.addEventListener("click", () => {
                if (btn.disabled) return;

                selectedRating = option.rating;

                [...ratingContainer.children].forEach(b =>
                    b.classList.remove("bg-primary-600", "text-white")
                );

                btn.classList.add("bg-primary-600", "text-white");

                // Show comment only for negative / neutral
                if (option.rating <= 7) {
                    commentBox.classList.remove("hidden");
                } else {
                    commentBox.classList.add("hidden");
                }
            });

            ratingContainer.appendChild(btn);
        });

        window.openReviewModal = async function() {

            if (isCheckingReview) return;
            isCheckingReview = true;

            // ========= FULL UI RESET (CRITICAL FIX) =========

            // show main sections again
            document.getElementById("ratingSection").classList.remove("hidden");
            document.getElementById("footerButtons").classList.remove("hidden");

            // hide confirm popup
            confirmPopup.classList.add("hidden");

            // reset comment box
            commentBox.classList.add("hidden");
            document.getElementById("reviewComment").value = "";

            // reset rating selection
            selectedRating = null;
            document.querySelectorAll(".review-numbers").forEach(btn => {
                btn.classList.remove("review-numbers-selected");
            });


            // 🔒 RESET UI BEFORE SHOWING MODAL
            alreadyBtn.classList.add("hidden");
            alreadyBtn.disabled = false;
            alreadyBtn.textContent = "Already Submitted ?";

            submitBtn.disabled = false;
            submitBtn.classList.remove("opacity-50", "cursor-not-allowed");

            alertContainer.innerHTML = "";
            confirmPopup.classList.add("hidden");

            // enable everything
            document.querySelectorAll(".review-numbers").forEach(btn => {
                btn.disabled = false;
                btn.classList.remove("opacity-40", "cursor-not-allowed");
            });

            document.getElementById("reviewComment").disabled = false;

            // 👉 SHOW MODAL ONLY AFTER RESET
            modal.classList.remove("hidden");

            try {
                const res = await fetch(
                    "api/check-review.php?instance_id=<?php echo $instanceId; ?>"
                );
                const data = await res.json();

                if (!data.exists) return;

                alreadyBtn.classList.remove("hidden");

                if (data.submitted === 1) {

                    alreadyBtn.disabled = true;
                    alreadyBtn.textContent = "Already submitted";
                    alreadyBtn.classList.add("opacity-50", "cursor-not-allowed");

                    submitBtn.disabled = true;
                    submitBtn.classList.add("opacity-50", "cursor-not-allowed");

                    document.querySelectorAll(".review-numbers").forEach(btn => {
                        btn.disabled = true;
                        btn.classList.add("opacity-40", "cursor-not-allowed");
                    });

                    document.getElementById("reviewComment").disabled = true;

                    alertContainer.innerHTML = `
                <div class="bg-success-100 text-success-700 border-l-4 border-success-600 p-3 rounded-md text-sm font-medium">
                    <i class="fa-solid fa-check-circle"></i>
                    You already submitted your review.
                </div>
            `;
                }

            } catch (err) {
                console.error("Review check failed", err);
            } finally {
                isCheckingReview = false;
            }
        };




        // ========= Open Modal With Check =========
        openBtn?.addEventListener("click", openReviewModal);


        closeBtn.addEventListener("click", () => {
            modal.classList.add("hidden");
            // Don't redirect when just closing the popup
        });
        remindBtn?.addEventListener("click", () => modal.classList.add("hidden"));

        // Submit button
        submitBtn.addEventListener("click", () => {
            submitReview();
        });

        // Already Submitted button (SEPARATE)
        alreadyBtn.addEventListener("click", async () => {

            if (alreadyBtn.disabled) return;

            await fetch("api/already-submitted.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    instance_id: "<?php echo $instanceId; ?>"
                })
            });

            alreadyBtn.disabled = true;
            alreadyBtn.textContent = "Already submitted";
            alreadyBtn.classList.add("opacity-50", "cursor-not-allowed");

            alertContainer.innerHTML = `
        <div class="bg-success-100 text-success-700 border-l-4 border-success-600 p-3 rounded-md text-sm font-medium">
            <i class="fa-solid fa-check-circle"></i>
            You already submitted your review.
        </div>
    `;
            setTimeout(() => {
                modal.classList.add("hidden");
                // Don't redirect when closing - just hide the modal
            }, 500);

        });
    });



    // ========= GLOBAL REDIRECT HANDLER =========
    window.redirectAfterReview = function() {

        // ✅ Change this if needed
        const redirectUrl = window.pendingRedirectUrl ||
            "dashboard.php";

        // Small delay for UX
        setTimeout(() => {
            window.location.href = redirectUrl;
        }, 300);
    };
</script>