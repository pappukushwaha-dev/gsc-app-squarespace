</div>

<?php include './partials/footer.php' ?>
</main>

<?php include './partials/script.php' ?>
<?php
// Prepare variables for ticket popup
if (!isset($siteUrl)) {
    $siteUrl = '';
    if (isset($instanceId) && $instanceId) {
        try {
            $stmt = $pdo->prepare("
                SELECT shop_domain
                FROM EcwidSite
                WHERE instance_id = ?
                LIMIT 1
            ");
            $stmt->execute([$instanceId]);
            $shopDomain = $stmt->fetchColumn();
            if ($shopDomain) {
                $siteUrl = 'https://' . $shopDomain;
            }
        } catch (Throwable $e) {
            // Ignore errors
        }
    }
}
include './partials/ticket-submit-popup.php';
?>
<div id="alert-container" class="fixed top-64 right-[35%] space-y-3 z-50"></div>

</body>
</html>