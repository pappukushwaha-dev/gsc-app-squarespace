<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/google/get_account.php';
require_once __DIR__ . '/../../includes/google/token_manager.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ==========================================================
   INPUT
========================================================== */
$instanceId = $_GET['instanceId']
    ?? $_SESSION['instance_id']
    ?? $_SESSION['instanceid']
    ?? null;

$domain = $_GET['domain'] ?? null;

if (!$instanceId || !$domain) {
    echo json_encode([
        'success' => false,
        'error'   => 'missing_parameters'
    ]);
    exit;
}

$domain   = strtolower(trim($domain));
$property = 'https://' . $domain . '/';

/* ==========================================================
   LOAD GOOGLE ACCOUNT
========================================================== */
$google = getGoogleAccountByInstance($instanceId);

if (!$google || empty($google['access_token'])) {
    echo json_encode([
        'success' => false,
        'error'   => 'account_needs_reconnect'
    ]);
    exit;
}

/* ==========================================================
   ENSURE ACCESS TOKEN
========================================================== */
$accountId   = (int) $google['id'];
$tokenResult = ensureAccessToken($accountId, 120);

$accessToken = $tokenResult['access_token'] ?? $google['access_token'];

if (empty($accessToken)) {
    echo json_encode([
        'success' => false,
        'error'   => 'account_needs_reconnect'
    ]);
    exit;
}

/* ==========================================================
   CALL SEARCH CONSOLE API (LIST SITES)
========================================================== */
$apiUrl = 'https://www.googleapis.com/webmasters/v3/sites';

$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
        "Authorization: Bearer {$accessToken}",
        "Accept: application/json"
    ],
    CURLOPT_TIMEOUT        => 15,
    CURLOPT_USERAGENT      => 'Shopify-GSC/1.0'
]);

$response = curl_exec($ch);
$http     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    echo json_encode([
        'success' => false,
        'error'   => 'network_error',
        'message' => $curlErr
    ]);
    exit;
}

if ($http === 401 || $http === 403) {
    echo json_encode([
        'success' => false,
        'error'   => 'account_needs_reconnect'
    ]);
    exit;
}

$data = json_decode((string) $response, true);

if (!is_array($data)) {
    echo json_encode([
        'success' => false,
        'error'   => 'invalid_google_response'
    ]);
    exit;
}

// Empty body or no siteEntry = account has no properties yet (not an error)
$siteEntries = $data['siteEntry'] ?? [];

/* ==========================================================
   CHECK PROPERTY EXISTENCE
========================================================== */
$exists   = false;
$verified = false;

foreach ($siteEntries as $site) {
    if (($site['siteUrl'] ?? '') === $property) {
        $exists   = true;
        $verified = ($site['permissionLevel'] ?? '') !== 'siteUnverifiedUser';
        break;
    }
}

echo json_encode([
    'success'  => true,
    'exists'   => $exists,
    'verified' => $verified
]);
exit;
