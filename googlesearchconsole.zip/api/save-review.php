<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/config.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['instance_id'], $data['rating']) || !is_numeric($data['rating'])) {
    echo json_encode(['success' => false]);
    exit;
}

$instanceId = $data['instance_id'];
$rating     = (int)$data['rating'];
$comment    = ($rating >= 8) ? "shopify review app" : ($data['comment'] ?? null);

$ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;

// fetch owner email from EcwidSite
$q = $pdo->prepare("
    SELECT email 
    FROM EcwidSite 
    WHERE instance_id = :id 
      AND is_active = 1
    LIMIT 1
");
$q->execute([':id' => $instanceId]);
$row = $q->fetch(PDO::FETCH_ASSOC);

if (!$row || empty($row['email'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Shop not found or email not available'
    ]);
    exit;
}

// ALWAYS INSERT (multiple feedback allowed)
$insert = $pdo->prepare("
    INSERT INTO app_reviews
    (instance_id, email, rating, comment, ip_address, user_agent, created_at)
    VALUES
    (:instance_id, :email, :rating, :comment, :ip, :agent, NOW())
");

$insert->execute([
    ':instance_id' => $instanceId,
    ':email'       => $row['email'],
    ':rating'      => $rating,
    ':comment'     => $comment,
    ':ip'          => $ipAddress,
    ':agent'       => $userAgent
]);

echo json_encode([
    'success' => true,
    'message' => 'Review submitted successfully.'
]);
exit;
